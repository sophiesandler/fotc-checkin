FOTC UI update 3. Six files changed: home.py, ui.py, dashboard.py, pilot.py, views.py, db.py.
Upload those six .py files themselves to GitHub (Add file > Upload files). Do NOT upload the zip.
Then Manage app > Reboot app.
