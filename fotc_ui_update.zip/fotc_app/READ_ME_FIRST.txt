FOTC UI update (clickable cards, season dropdown).
Only three files changed: home.py, ui.py, dashboard.py.
Safest: upload just those three to GitHub (replace the old ones), then Manage app > Reboot app.
The whole app is included in case you want to replace everything. Keep .streamlit/config.toml as it is.
