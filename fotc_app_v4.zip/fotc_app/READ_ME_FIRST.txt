FOTC question update (v4). Thirteen files changed: answers.py content.py dashboard.py db.py home.py launch.py pilot.py pipeline.py risk.py seed_content.json tagging.py ui.py views.py.
Upload those thirteen files themselves to GitHub (Add file > Upload files). Do NOT upload the zip.
Then Manage app > Reboot app. The first sign-in after the reboot upgrades your question set once.
